import type { PageMeta } from '@/lib/seo';

export const meta: PageMeta = {
  title: 'Partners',
  description:
    'Global systems integrators, technology alliances, regional resellers and managed service providers delivering Ironstack inside enterprise environments.',
  path: '/partners',
  breadcrumbs: [{ name: 'Partners', href: '/partners' }],
};
