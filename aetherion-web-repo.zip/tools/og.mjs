/**
 * Generates the OpenGraph card.
 *
 * Rendered through the real design system in headless Chromium rather than
 * drawn by hand, so the social card cannot drift from the site's typography
 * and palette. Run after a build; writes public/og/default.png.
 */

import fs from 'node:fs/promises';
import path from 'node:path';
import { chromium } from 'playwright';

const ROOT = path.resolve(import.meta.dirname, '..');
const fontRegular = await fs.readFile(
  path.join(ROOT, 'public/fonts/InterVariable.woff2'),
);
const fontMono = await fs.readFile(
  path.join(ROOT, 'public/fonts/JetBrainsMonoVariable.woff2'),
);
const mark = await fs.readFile(path.join(ROOT, 'public/brand/logo-mark.svg'), 'utf8');

const html = `<!doctype html>
<html><head><meta charset="utf-8"><style>
@font-face{font-family:Inter;src:url(data:font/woff2;base64,${fontRegular.toString('base64')}) format('woff2');font-weight:100 900}
@font-face{font-family:JB;src:url(data:font/woff2;base64,${fontMono.toString('base64')}) format('woff2');font-weight:100 800}
*{margin:0;padding:0;box-sizing:border-box}
body{width:1200px;height:630px;background:#06080c;font-family:Inter;color:#f2f5fa;overflow:hidden;position:relative;
 -webkit-font-smoothing:antialiased}
.mesh{position:absolute;inset:0;background-image:linear-gradient(to right,rgba(255,255,255,.035) 1px,transparent 1px),linear-gradient(to bottom,rgba(255,255,255,.035) 1px,transparent 1px);background-size:64px 64px;
 -webkit-mask-image:radial-gradient(120% 100% at 20% 0%,#000 20%,transparent 78%)}
.aurora{position:absolute;width:900px;height:900px;left:-180px;top:-320px;border-radius:50%;
 background:radial-gradient(circle,rgba(0,194,168,.30),transparent 62%);filter:blur(90px)}
.aurora2{position:absolute;width:820px;height:820px;right:-220px;bottom:-380px;border-radius:50%;
 background:radial-gradient(circle,rgba(106,79,245,.34),transparent 62%);filter:blur(90px)}
.wrap{position:relative;height:100%;display:flex;flex-direction:column;justify-content:space-between;padding:64px 72px}
.brand{display:flex;align-items:center;gap:14px}
.brand svg{width:44px;height:44px}
.brand span{font-size:30px;font-weight:590;letter-spacing:-.03em}
h1{font-size:66px;line-height:1.05;letter-spacing:-.038em;font-weight:590;max-width:17ch}
.grad{background:linear-gradient(96deg,#fff 8%,#b3fff0 46%,#9d8dff 98%);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
p{margin-top:22px;font-size:23px;line-height:1.5;color:#b6bfd0;max-width:34ch;letter-spacing:-.012em}
.foot{display:flex;align-items:center;gap:28px;font-family:JB;font-size:16px;color:#8a94a8;letter-spacing:.02em}
.foot i{width:6px;height:6px;border-radius:50%;background:#16d9bd;display:inline-block;margin-right:9px;
 box-shadow:0 0 0 4px rgba(22,217,189,.18)}
.rule{height:1px;background:linear-gradient(90deg,rgba(255,255,255,.16),transparent);margin-bottom:26px}
</style></head><body>
<div class="aurora"></div><div class="aurora2"></div><div class="mesh"></div>
<div class="wrap">
  <div class="brand">${mark}<span>Aetherion</span></div>
  <div>
    <h1>Autonomous infrastructure operations <span class="grad">for modern enterprises</span></h1>
    <p>Discovery, patching, upgrades, migrations, compliance and self-healing — from one intelligent platform.</p>
  </div>
  <div>
    <div class="rule"></div>
    <div class="foot"><span><i></i>77 technologies</span><span>180+ integrations</span><span>SOC 2 · ISO 27001 · FedRAMP</span><span style="margin-left:auto">aetherion.ai</span></div>
  </div>
</div>
</body></html>`;

const browser = await chromium.launch();
const page = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 2,
});
await page.setContent(html, { waitUntil: 'load' });
await page.evaluate(() => document.fonts.ready);
await page.waitForTimeout(300);
await fs.mkdir(path.join(ROOT, 'public/og'), { recursive: true });
await page.screenshot({ path: path.join(ROOT, 'public/og/default.png') });
await browser.close();
console.log('public/og/default.png written');
