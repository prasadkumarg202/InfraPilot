'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { demoScenarios, type DemoScenario } from '@/content/demos';
import { Badge, Icon } from '@/components/primitives';
import { TopologyGraph, paymentsEstate } from '@/components/visualizations/TopologyGraph';
import { cx, seededRandom, round } from '@/lib/utils';

/**
 * Demo theatre.
 *
 * Plays a scripted run of a real workflow. Each scenario is a sequence of
 * phases; the player emits one log line at a time and drives a scenario
 * specific visual from the same progress value, so the log, the progress bar
 * and the picture can never disagree.
 *
 * Autoplay starts only once the component is on screen and stops when it
 * leaves, so a page with several demos never runs timers the visitor can't see.
 */

const LINE_MS = 900;

export function DemoTheatre({ initial = 0 }: { initial?: number }) {
  const [active, setActive] = useState(initial);
  const [step, setStep] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [visible, setVisible] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const logRef = useRef<HTMLOListElement>(null);

  const scenario = demoScenarios[active];

  /** Flattened log stream so the player has one linear index to advance. */
  const stream = useMemo(() => {
    const out: Array<{
      phase: number;
      phaseId: string;
      text: string;
      tone: string;
    }> = [];
    scenario.phases.forEach((phase, phaseIndex) => {
      phase.logs.forEach((log) => {
        out.push({ phase: phaseIndex, phaseId: phase.id, text: log.text, tone: log.tone });
      });
    });
    return out;
  }, [scenario]);

  const total = stream.length;
  const finished = step >= total;
  const progress = total ? Math.min(step / total, 1) : 0;
  const currentPhase = finished
    ? scenario.phases.length - 1
    : (stream[step]?.phase ?? 0);

  useEffect(() => {
    const node = rootRef.current;
    if (!node || !('IntersectionObserver' in window)) {
      setVisible(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => setVisible(entry.isIntersecting),
      { threshold: 0.25 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  // Autoplay once, the first time the theatre scrolls into view.
  const startedRef = useRef(false);
  useEffect(() => {
    if (visible && !startedRef.current) {
      startedRef.current = true;
      setPlaying(true);
    }
  }, [visible]);

  useEffect(() => {
    if (!playing || !visible || finished) return;
    const reduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) {
      setStep(total);
      setPlaying(false);
      return;
    }
    const timer = setTimeout(() => setStep((s) => s + 1), LINE_MS);
    return () => clearTimeout(timer);
  }, [playing, visible, finished, step, total]);

  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [step]);

  const select = useCallback((index: number) => {
    setActive(index);
    setStep(0);
    setPlaying(true);
  }, []);

  const restart = useCallback(() => {
    setStep(0);
    setPlaying(true);
  }, []);

  return (
    <div className="theatre" ref={rootRef}>
      {/* -------------------------------------------------------- Scenarios */}
      <div className="theatre__tabs" role="tablist" aria-label="Demo scenarios">
        {demoScenarios.map((item, index) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            id={`demo-tab-${item.id}`}
            aria-selected={index === active}
            aria-controls={`demo-panel-${item.id}`}
            className={cx('theatre__tab', index === active && 'is-active')}
            onClick={() => select(index)}
          >
            <span className="theatre__tab-icon">
              <Icon name={item.icon} size={17} />
            </span>
            <span className="theatre__tab-text">
              <span className="theatre__tab-name">{item.name}</span>
              <span className="theatre__tab-line">{item.tagline}</span>
            </span>
          </button>
        ))}
      </div>

      {/* ----------------------------------------------------------- Stage */}
      <div
        className="theatre__stage"
        role="tabpanel"
        id={`demo-panel-${scenario.id}`}
        aria-labelledby={`demo-tab-${scenario.id}`}
      >
        <header className="theatre__head">
          <div>
            <h3 className="theatre__title">{scenario.name}</h3>
            <p className="theatre__scope">{scenario.scope}</p>
          </div>
          <div className="theatre__controls">
            <Badge tone={finished ? 'success' : 'accent'} live={!finished && playing}>
              {finished ? 'Complete' : playing ? 'Running' : 'Paused'}
            </Badge>
            <button
              type="button"
              className="btn btn--ghost btn--icon btn--sm"
              onClick={() => (finished ? restart() : setPlaying((p) => !p))}
              aria-label={finished ? 'Replay' : playing ? 'Pause' : 'Play'}
            >
              <Icon name={finished ? 'refresh' : playing ? 'pause' : 'play'} size={16} />
            </button>
            <button
              type="button"
              className="btn btn--ghost btn--icon btn--sm"
              onClick={restart}
              aria-label="Restart"
            >
              <Icon name="rewind" size={16} />
            </button>
          </div>
        </header>

        <p className="theatre__description">{scenario.description}</p>

        {/* Phase rail */}
        <ol className="theatre__phases">
          {scenario.phases.map((phase, index) => (
            <li
              key={phase.id}
              className={cx(
                index < currentPhase || finished ? 'is-done' : null,
                index === currentPhase && !finished ? 'is-active' : null,
              )}
            >
              <span className="theatre__phase-bar">
                <i
                  style={{
                    width:
                      index < currentPhase || finished
                        ? '100%'
                        : index === currentPhase
                          ? `${phaseProgress(stream, step, index)}%`
                          : '0%',
                  }}
                />
              </span>
              <span className="theatre__phase-label">{phase.label}</span>
            </li>
          ))}
        </ol>

        <div className="theatre__body">
          <div className="theatre__visual">
            <ScenarioVisual scenario={scenario} progress={progress} />
          </div>

          <ol className="theatre__log" ref={logRef} aria-live="polite">
            {stream.slice(0, step).map((line, index) => (
              <li key={`${line.phaseId}-${index}`} className={`is-${line.tone}`}>
                <span className="theatre__log-time" data-numeric>
                  {timeStamp(index)}
                </span>
                <span className="theatre__log-text">{line.text}</span>
              </li>
            ))}
            {!finished && (
              <li className="theatre__log-cursor" aria-hidden="true">
                <span className="theatre__log-time">…</span>
                <span className="theatre__log-text">
                  <i />
                </span>
              </li>
            )}
          </ol>
        </div>

        {/* Metrics */}
        <div className="theatre__metrics">
          {scenario.metrics.map((metric) => (
            <div key={metric.label} className="theatre__metric">
              <span className="theatre__metric-label">{metric.label}</span>
              <span className="theatre__metric-values">
                <span className="theatre__metric-from">{metric.from}</span>
                <Icon name="arrowRight" size={12} />
                <span className={cx('theatre__metric-to', finished && 'is-settled')}>
                  {finished ? metric.to : '—'}
                </span>
              </span>
            </div>
          ))}
        </div>

        {finished && (
          <p className="theatre__outcome">
            <Icon name="checkCircle" size={16} />
            {scenario.outcome}
          </p>
        )}
      </div>
    </div>
  );
}

function phaseProgress(
  stream: Array<{ phase: number }>,
  step: number,
  phase: number,
): number {
  const inPhase = stream.filter((l) => l.phase === phase).length;
  const before = stream.filter((l) => l.phase < phase).length;
  if (!inPhase) return 0;
  return Math.max(0, Math.min(100, ((step - before) / inPhase) * 100));
}

function timeStamp(index: number): string {
  const total = 8 + index * 37;
  const m = String(Math.floor(total / 60)).padStart(2, '0');
  const s = String(total % 60).padStart(2, '0');
  return `00:${m}:${s}`;
}

/* ==========================================================================
   SCENARIO VISUALS
   Each reads the same 0–1 progress value, so the picture and the log are
   always describing the same moment.
   ======================================================================= */

function ScenarioVisual({
  scenario,
  progress,
}: {
  scenario: DemoScenario;
  progress: number;
}) {
  switch (scenario.visual) {
    case 'waves':
      return <WaveVisual progress={progress} />;
    case 'migration':
      return <MigrationVisual progress={progress} />;
    case 'evidence':
      return <EvidenceVisual progress={progress} />;
    case 'compliance':
      return <ComplianceVisual progress={progress} />;
    default:
      return (
        <div className="theatre__topology">
          <TopologyGraph
            nodes={paymentsEstate.nodes}
            edges={paymentsEstate.edges}
            width={620}
            height={300}
            idPrefix="demo-topo"
            compact
          />
        </div>
      );
  }
}

/* ---------------------------------------------------------------- Waves */

const WAVES = [
  { label: 'EMEA · wave 1', count: 238, start: 0.0 },
  { label: 'EMEA · wave 2', count: 214, start: 0.08 },
  { label: 'AMER · wave 1', count: 302, start: 0.2 },
  { label: 'AMER · wave 2', count: 288, start: 0.32 },
  { label: 'APAC · wave 1', count: 302, start: 0.46 },
  { label: 'APAC · wave 2', count: 264, start: 0.58 },
  { label: 'LATAM · wave 1', count: 246, start: 0.7 },
  { label: 'Trailing · retries', count: 250, start: 0.82 },
];

function WaveVisual({ progress }: { progress: number }) {
  return (
    <div className="viz-waves">
      {WAVES.map((wave, index) => {
        const local = Math.max(0, Math.min(1, (progress - wave.start) / 0.2));
        const done = Math.round(wave.count * local);
        const warn = index === 2 && local > 0.5;
        return (
          <div key={wave.label} className="viz-waves__row">
            <span className="viz-waves__label">{wave.label}</span>
            <span className="viz-waves__track">
              <i
                className={cx(local >= 1 ? 'is-done' : 'is-run', warn && 'has-warn')}
                style={{ width: `${local * 100}%` }}
              />
            </span>
            <span className="viz-waves__count" data-numeric>
              {done}/{wave.count}
            </span>
          </div>
        );
      })}
    </div>
  );
}

/* ------------------------------------------------------------ Migration */

const MIGRATION_STAGES = [
  { label: 'Source schemas', value: '46', icon: 'database' as const },
  { label: 'Objects converted', value: '8,412', icon: 'refresh' as const },
  { label: 'Data reconciled', value: '3.8 TB', icon: 'checkCircle' as const },
  { label: 'Target live', value: 'PostgreSQL 16', icon: 'cloud' as const },
];

function MigrationVisual({ progress }: { progress: number }) {
  return (
    <div className="viz-migration">
      <div className="viz-migration__rail">
        <span className="viz-migration__fill" style={{ width: `${progress * 100}%` }} />
      </div>
      <div className="viz-migration__stages">
        {MIGRATION_STAGES.map((stage, index) => {
          const reached = progress >= index / MIGRATION_STAGES.length;
          return (
            <div
              key={stage.label}
              className={cx('viz-migration__stage', reached && 'is-reached')}
            >
              <span className="viz-migration__icon">
                <Icon name={stage.icon} size={16} />
              </span>
              <span className="viz-migration__value" data-numeric>
                {reached ? stage.value : '—'}
              </span>
              <span className="viz-migration__label">{stage.label}</span>
            </div>
          );
        })}
      </div>
      <div className="viz-migration__lag">
        <span>Replication lag</span>
        <span data-numeric>
          {progress < 0.5
            ? '—'
            : progress < 0.95
              ? `${round(4.2 * (1 - progress), 1)}s`
              : '0.0s'}
        </span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------- Evidence */

const CANDIDATES = [
  { name: 'Statistics stale after index rebuild', confidence: 91, verdict: 'cause' },
  { name: 'Connection pool exhaustion', confidence: 38, verdict: 'symptom' },
  { name: 'Network path degradation', confidence: 6, verdict: 'ruled-out' },
  { name: 'Kafka consumer lag', confidence: 4, verdict: 'ruled-out' },
];

function EvidenceVisual({ progress }: { progress: number }) {
  const random = seededRandom(42);
  const series = Array.from({ length: 40 }, (_, i) => {
    const spike = i > 22 && i < 33 ? 3.2 : 0;
    const recovery = i >= 33 ? -0.2 : 0;
    return 0.9 + random() * 0.25 + spike + recovery;
  });
  const max = Math.max(...series);
  const shown = Math.round(series.length * Math.min(1, progress * 1.4));

  return (
    <div className="viz-evidence">
      <div className="viz-evidence__chart">
        <span className="viz-evidence__chart-label">Checkout p99 latency</span>
        <svg viewBox="0 0 300 74" preserveAspectRatio="none" aria-hidden="true">
          <line x1="0" y1="20" x2="300" y2="20" className="viz-evidence__threshold" />
          {series.slice(0, shown).map((value, i) => (
            <rect
              key={i}
              x={i * 7.5}
              width="5"
              y={74 - (value / max) * 68}
              height={(value / max) * 68}
              className={value > 2 ? 'is-breach' : 'is-ok'}
            />
          ))}
        </svg>
      </div>
      <ul className="viz-evidence__candidates">
        {CANDIDATES.map((candidate, index) => {
          const reached = progress > 0.45 + index * 0.06;
          return (
            <li
              key={candidate.name}
              className={cx(`is-${candidate.verdict}`, reached && 'is-shown')}
            >
              <span className="viz-evidence__name">{candidate.name}</span>
              <span className="viz-evidence__bar">
                <i style={{ width: reached ? `${candidate.confidence}%` : '0%' }} />
              </span>
              <span className="viz-evidence__conf" data-numeric>
                {reached ? `${candidate.confidence}%` : '—'}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

/* ----------------------------------------------------------- Compliance */

function ComplianceVisual({ progress }: { progress: number }) {
  const random = seededRandom(7);
  const cells = Array.from({ length: 96 }, () => random());
  const posture = 87.4 + (99.1 - 87.4) * progress;

  return (
    <div className="viz-compliance">
      <div className="viz-compliance__head">
        <div>
          <span className="viz-compliance__value" data-numeric>
            {posture.toFixed(1)}%
          </span>
          <span className="viz-compliance__label">PCI DSS 4.0 posture</span>
        </div>
        <div className="viz-compliance__legend">
          <span>
            <i className="is-pass" /> Pass
          </span>
          <span>
            <i className="is-fail" /> Fail
          </span>
          <span>
            <i className="is-accepted" /> Accepted
          </span>
        </div>
      </div>
      <div className="viz-compliance__grid">
        {cells.map((seed, index) => {
          const wasFailing = seed > 0.86;
          const stillFailing = wasFailing && seed > 0.86 + progress * 0.11;
          const accepted = wasFailing && !stillFailing && seed > 0.965;
          return (
            <span
              key={index}
              className={cx(
                'viz-compliance__cell',
                stillFailing ? 'is-fail' : accepted ? 'is-accepted' : 'is-pass',
              )}
            />
          );
        })}
      </div>
    </div>
  );
}
