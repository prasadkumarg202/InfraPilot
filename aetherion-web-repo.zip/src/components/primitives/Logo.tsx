import { site } from '@/content/site.config';
import { cx } from '@/lib/utils';

/**
 * Brand mark.
 *
 * An aperture built from two interlocking angular strokes that read as an "A"
 * while also describing a closed control loop — the shape of an automation
 * system that observes and corrects itself. The node at the centre is the
 * only filled element, so the mark stays legible down to 16px where the
 * strokes start to merge.
 */

interface MarkProps {
  size?: number;
  className?: string;
  /** Renders in a single colour instead of the brand gradient. */
  monochrome?: boolean;
  idPrefix?: string;
}

export function LogoMark({
  size = 32,
  className,
  monochrome = false,
  idPrefix = 'lm',
}: MarkProps) {
  const gradId = `${idPrefix}-grad`;
  const glowId = `${idPrefix}-glow`;
  const stroke = monochrome ? 'currentColor' : `url(#${gradId})`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      role="img"
      aria-label={`${site.name} logo`}
      className={className}
    >
      <defs>
        <linearGradient id={gradId} x1="4" y1="36" x2="36" y2="4" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#40e8d0" />
          <stop offset="48%" stopColor="#16d9bd" />
          <stop offset="100%" stopColor="#8069ff" />
        </linearGradient>
        <radialGradient id={glowId} cx="0.5" cy="0.5" r="0.5">
          <stop offset="0%" stopColor="#7af4e2" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#7af4e2" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* Outer aperture — the ascending stroke of the A */}
      <path
        d="M20 3.5 5.2 33.2a2.2 2.2 0 0 0 1.97 3.2h5.03"
        stroke={stroke}
        strokeWidth="3.1"
        strokeLinecap="round"
      />
      {/* Descending stroke, broken to form the control-loop gap */}
      <path
        d="M27.8 36.4h5.03a2.2 2.2 0 0 0 1.97-3.2L26.4 15.9"
        stroke={stroke}
        strokeWidth="3.1"
        strokeLinecap="round"
      />
      {/* Crossbar, offset to imply flow direction rather than symmetry */}
      <path
        d="M14.1 25.6h11.8"
        stroke={stroke}
        strokeWidth="3.1"
        strokeLinecap="round"
        opacity="0.55"
      />
      {/* Core node */}
      {!monochrome && (
        <circle cx="20" cy="25.6" r="7" fill={`url(#${glowId})`} opacity="0.5" />
      )}
      <circle cx="20" cy="25.6" r="2.9" fill={monochrome ? 'currentColor' : '#7af4e2'} />
    </svg>
  );
}

interface LogoProps extends MarkProps {
  /** Hides the wordmark, leaving just the mark. */
  markOnly?: boolean;
  /** Optional product lockup, e.g. "Docs" or "Platform". */
  suffix?: string;
}

export function Logo({
  size = 30,
  className,
  monochrome = false,
  markOnly = false,
  suffix,
  idPrefix = 'logo',
}: LogoProps) {
  return (
    <span className={cx('logo', className)}>
      <LogoMark size={size} monochrome={monochrome} idPrefix={idPrefix} />
      {!markOnly && (
        <span className="logo__word" aria-hidden={false}>
          {site.name}
        </span>
      )}
      {suffix && (
        <>
          <span className="logo__divider" aria-hidden="true" />
          <span className="logo__suffix">{suffix}</span>
        </>
      )}
    </span>
  );
}
