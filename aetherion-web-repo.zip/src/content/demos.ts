import type { IconName } from '@/components/primitives/Icon';

/**
 * Interactive demo scenarios.
 *
 * Each scenario is a scripted run: a list of phases, the log lines each phase
 * emits, and the metrics that change as it progresses. The player component
 * advances through them so a visitor can watch a real workflow shape without
 * booking a call.
 */

export type DemoVisual =
  | 'topology'
  | 'waves'
  | 'evidence'
  | 'compliance'
  | 'migration'
  | 'rollback';

export interface DemoPhase {
  id: string;
  label: string;
  /** Seconds of simulated run time this phase represents. */
  duration: number;
  logs: Array<{ text: string; tone: 'info' | 'ok' | 'warn' | 'ai' | 'danger' }>;
}

export interface DemoScenario {
  id: string;
  name: string;
  icon: IconName;
  tagline: string;
  description: string;
  visual: DemoVisual;
  scope: string;
  phases: DemoPhase[];
  metrics: Array<{ label: string; from: string; to: string }>;
  outcome: string;
}

export const demoScenarios: DemoScenario[] = [
  {
    id: 'patch',
    name: 'Patch orchestration',
    icon: 'shield',
    tagline: '2,104 SQL Server instances, one window',
    description:
      'A quarterly cumulative update across a global availability-group estate. Waves are derived from the dependency graph so quorum is never at risk, and health gates decide whether the next wave starts.',
    visual: 'waves',
    scope: '2,104 instances · 4 regions · 6-hour window',
    outcome:
      'Completed in 4h 12m with zero unplanned downtime. Two nodes rolled back automatically on a failed health check and were re-run in the trailing wave.',
    phases: [
      {
        id: 'plan',
        label: 'Plan waves',
        duration: 42,
        logs: [
          { text: 'Resolving dependency graph for 2,104 instances', tone: 'info' },
          { text: '38 availability groups detected — quorum constraints applied', tone: 'info' },
          { text: 'Copilot proposed 9 waves; 3 nodes re-sequenced to protect quorum', tone: 'ai' },
          { text: 'Change risk scored 18/100 (low) against 4,206 prior changes', tone: 'ok' },
        ],
      },
      {
        id: 'preflight',
        label: 'Pre-flight',
        duration: 134,
        logs: [
          { text: 'Disk headroom verified on 2,104 targets', tone: 'ok' },
          { text: 'Backup chain validated — 2,101 current, 3 remediated', tone: 'warn' },
          { text: 'Maintenance window confirmed with ServiceNow CHG0048812', tone: 'ok' },
          { text: 'Credentials brokered from CyberArk for wave 1', tone: 'ok' },
        ],
      },
      {
        id: 'execute',
        label: 'Rolling execution',
        duration: 12_480,
        logs: [
          { text: 'Wave 1 · EMEA · 238 instances — draining secondaries', tone: 'info' },
          { text: 'CU19 applied to 238 instances · 0 failures', tone: 'ok' },
          { text: 'Wave 3 · AMER · health gate failed on 2 nodes — rolled back', tone: 'warn' },
          { text: 'Failed nodes re-queued to trailing wave with diagnostics attached', tone: 'ai' },
          { text: 'Wave 7 · APAC · 302 instances complete', tone: 'ok' },
        ],
      },
      {
        id: 'validate',
        label: 'Validate & close',
        duration: 268,
        logs: [
          { text: 'Post-patch checks passed on 2,102 of 2,104', tone: 'ok' },
          { text: 'Failover tested on 38 availability groups', tone: 'ok' },
          { text: 'Evidence package written to audit log and attached to CHG0048812', tone: 'ok' },
          { text: 'Change closed automatically — no manual steps required', tone: 'ok' },
        ],
      },
    ],
    metrics: [
      { label: 'Instances patched', from: '0', to: '2,104' },
      { label: 'Unplanned downtime', from: '—', to: '0 min' },
      { label: 'Manual engineer hours', from: '840', to: '6' },
      { label: 'Elapsed', from: '00:00', to: '04:12' },
    ],
  },
  {
    id: 'migration',
    name: 'Database migration',
    icon: 'route',
    tagline: 'Oracle 12c on-premises to PostgreSQL on Azure',
    description:
      'A move group of 46 schemas lifted from an end-of-support Oracle estate into managed PostgreSQL, with cutover rehearsed against production data before the real window opens.',
    visual: 'migration',
    scope: '46 schemas · 3.8 TB · 11-hour rehearsal',
    outcome:
      'Cutover executed in 38 minutes against a rehearsed plan. Rollback path validated but not needed. Application teams signed off from the same evidence pack.',
    phases: [
      {
        id: 'assess',
        label: 'Assess',
        duration: 3600,
        logs: [
          { text: 'Schema analysis complete — 46 schemas, 8,412 objects', tone: 'info' },
          { text: '312 incompatible constructs identified', tone: 'warn' },
          { text: 'Copilot generated conversion rules for 297 of 312', tone: 'ai' },
          { text: '15 constructs flagged for engineer review', tone: 'warn' },
        ],
      },
      {
        id: 'build',
        label: 'Build target',
        duration: 1840,
        logs: [
          { text: 'Target provisioned via generated Terraform — committed to platform repo', tone: 'ok' },
          { text: 'Network path and private endpoint verified', tone: 'ok' },
          { text: 'Baseline hardening and monitoring applied', tone: 'ok' },
        ],
      },
      {
        id: 'rehearse',
        label: 'Rehearse cutover',
        duration: 39_600,
        logs: [
          { text: 'Initial load complete — 3.8 TB in 6h 41m', tone: 'ok' },
          { text: 'Change data capture caught up — lag 1.2s', tone: 'ok' },
          { text: 'Row and checksum reconciliation passed on 8,412 objects', tone: 'ok' },
          { text: 'Application smoke suite passed against target', tone: 'ok' },
          { text: 'Rollback rehearsed — 11m 04s to restore service on source', tone: 'ai' },
        ],
      },
      {
        id: 'cutover',
        label: 'Cutover',
        duration: 2280,
        logs: [
          { text: 'Traffic quiesced — 0 active sessions on source', tone: 'info' },
          { text: 'Final CDC drain complete — lag 0.0s', tone: 'ok' },
          { text: 'Connection strings rotated across 22 applications', tone: 'ok' },
          { text: 'Service restored on target — 38m 12s elapsed', tone: 'ok' },
        ],
      },
    ],
    metrics: [
      { label: 'Schemas migrated', from: '0', to: '46' },
      { label: 'Data reconciled', from: '0 TB', to: '3.8 TB' },
      { label: 'Cutover duration', from: 'est. 6h', to: '38 min' },
      { label: 'Rollback tested', from: 'No', to: 'Yes' },
    ],
  },
  {
    id: 'rca',
    name: 'AI root cause analysis',
    icon: 'target',
    tagline: 'Payment latency spike, 02:14 UTC',
    description:
      'Checkout latency crosses its threshold. The platform assembles evidence across the dependency path, correlates it with change history, and ranks candidate causes with the reasoning exposed.',
    visual: 'evidence',
    scope: 'P1 · payments · 4 candidate causes evaluated',
    outcome:
      'Root cause identified in 94 seconds — a statistics regression after an index rebuild. Remediation proposed, approved by the on-call engineer, and executed in 3 minutes.',
    phases: [
      {
        id: 'detect',
        label: 'Detect',
        duration: 12,
        logs: [
          { text: 'Dynatrace problem P-2291 — checkout p99 latency 4.8s (threshold 1.2s)', tone: 'danger' },
          { text: 'Impact scope resolved: 3 services, 1 customer journey', tone: 'info' },
          { text: 'Incident INC0092841 opened with topology snapshot attached', tone: 'ok' },
        ],
      },
      {
        id: 'gather',
        label: 'Gather evidence',
        duration: 34,
        logs: [
          { text: 'Collecting from 14 nodes along the dependency path', tone: 'info' },
          { text: 'Query plans, wait statistics and connection pools captured', tone: 'info' },
          { text: 'Change history queried — 3 changes in preceding 6 hours', tone: 'info' },
        ],
      },
      {
        id: 'correlate',
        label: 'Correlate',
        duration: 48,
        logs: [
          { text: 'Candidate 1 · Statistics stale after index rebuild — confidence 91%', tone: 'ai' },
          { text: 'Candidate 2 · Connection pool exhaustion — confidence 38% (symptom, not cause)', tone: 'ai' },
          { text: 'Candidate 3 · Network path degradation — ruled out, latency flat', tone: 'info' },
          { text: 'Candidate 4 · Kafka consumer lag — ruled out, downstream of symptom', tone: 'info' },
        ],
      },
      {
        id: 'remediate',
        label: 'Remediate',
        duration: 186,
        logs: [
          { text: 'Proposed remediation: update statistics on 4 objects, full scan', tone: 'ai' },
          { text: 'Approved by on-call engineer at 02:16:41', tone: 'ok' },
          { text: 'Executed — p99 latency returned to 0.9s', tone: 'ok' },
          { text: 'Preventive rule added: statistics refresh appended to index rebuild runbook', tone: 'ai' },
        ],
      },
    ],
    metrics: [
      { label: 'Time to diagnosis', from: '~45 min', to: '94 sec' },
      { label: 'Engineers paged', from: '4', to: '1' },
      { label: 'Candidates evaluated', from: '0', to: '4' },
      { label: 'Time to resolution', from: '~2h', to: '7 min' },
    ],
  },
  {
    id: 'healing',
    name: 'Incident auto-healing',
    icon: 'refresh',
    tagline: 'Tablespace exhaustion, unattended',
    description:
      'A known, well-precedented failure mode inside an approved policy envelope. The platform resolves it without paging anyone and records everything it did.',
    visual: 'topology',
    scope: 'Policy-bounded · production · no human in the loop',
    outcome:
      'Resolved in 71 seconds without human involvement. A change record was created retrospectively with the full evidence chain, and the capacity trend was raised as a separate planning item.',
    phases: [
      {
        id: 'signal',
        label: 'Signal',
        duration: 8,
        logs: [
          { text: 'Tablespace USERS at 94% on ledger-ora — threshold breached', tone: 'warn' },
          { text: 'Matched known failure mode KFM-0031 (17 prior occurrences)', tone: 'ai' },
        ],
      },
      {
        id: 'authorise',
        label: 'Policy check',
        duration: 3,
        logs: [
          { text: 'Policy PLC-UNATTENDED-STORAGE evaluated — permitted', tone: 'ok' },
          { text: 'Blast radius within limit: 1 instance, no dependent failover', tone: 'ok' },
          { text: 'Outside change freeze — proceeding unattended', tone: 'ok' },
        ],
      },
      {
        id: 'act',
        label: 'Remediate',
        duration: 52,
        logs: [
          { text: 'Extending datafile by 40 GB on managed disk', tone: 'info' },
          { text: 'Verifying free space on underlying volume — 1.2 TB available', tone: 'ok' },
          { text: 'Tablespace USERS now at 61%', tone: 'ok' },
        ],
      },
      {
        id: 'record',
        label: 'Record',
        duration: 8,
        logs: [
          { text: 'Change CHG0048907 created retrospectively with full evidence', tone: 'ok' },
          { text: 'Capacity trend raised for planning — projected exhaustion in 94 days', tone: 'ai' },
          { text: 'No engineer paged', tone: 'ok' },
        ],
      },
    ],
    metrics: [
      { label: 'Engineers paged', from: '1', to: '0' },
      { label: 'Time to resolution', from: '~35 min', to: '71 sec' },
      { label: 'Out-of-hours cost', from: '$1,840', to: '$0' },
      { label: 'Audit record', from: 'Manual', to: 'Automatic' },
    ],
  },
  {
    id: 'compliance',
    name: 'Compliance scanning',
    icon: 'shieldCheck',
    tagline: 'PCI DSS 4.0 across the cardholder data environment',
    description:
      'Controls tested continuously against every in-scope system, with exceptions assigned owners and remediation raised as governed change rather than a spreadsheet.',
    visual: 'compliance',
    scope: '412 systems in scope · 186 technical controls',
    outcome:
      'Posture moved from 87.4% to 99.1% in eleven days. Evidence exported in the assessor’s required format; no manual screenshot collection.',
    phases: [
      {
        id: 'scan',
        label: 'Test controls',
        duration: 1620,
        logs: [
          { text: '186 controls evaluated across 412 in-scope systems', tone: 'info' },
          { text: '76,632 individual checks executed', tone: 'info' },
          { text: '412 systems returned results — 0 unreachable', tone: 'ok' },
        ],
      },
      {
        id: 'assess',
        label: 'Assess gaps',
        duration: 96,
        logs: [
          { text: '52 failing controls across 118 systems', tone: 'warn' },
          { text: 'Req 8.3.6 · password policy non-compliant on 41 systems', tone: 'warn' },
          { text: 'Req 10.2 · audit logging incomplete on 22 systems', tone: 'warn' },
          { text: 'Copilot grouped 52 findings into 9 remediation workflows', tone: 'ai' },
        ],
      },
      {
        id: 'remediate',
        label: 'Remediate',
        duration: 8400,
        logs: [
          { text: 'Workflow 1 of 9 approved — password policy across 41 systems', tone: 'ok' },
          { text: '118 systems remediated under standard change', tone: 'ok' },
          { text: '4 findings accepted as risk with expiry dates and owners', tone: 'warn' },
        ],
      },
      {
        id: 'evidence',
        label: 'Produce evidence',
        duration: 42,
        logs: [
          { text: 'Evidence package generated — 186 controls, 412 systems', tone: 'ok' },
          { text: 'Exported to assessor template with per-check timestamps', tone: 'ok' },
          { text: 'Continuous monitoring enabled — next test in 24h', tone: 'ok' },
        ],
      },
    ],
    metrics: [
      { label: 'Compliance posture', from: '87.4%', to: '99.1%' },
      { label: 'Open findings', from: '52', to: '4' },
      { label: 'Evidence preparation', from: '6 weeks', to: '1 day' },
      { label: 'Systems in scope', from: '412', to: '412' },
    ],
  },
];
