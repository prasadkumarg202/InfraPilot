export interface CaseStudy {
  id: string;
  customerId: string;
  industry: string;
  title: string;
  challenge: string;
  approach: string;
  results: Array<{ value: string; label: string }>;
  quote: { text: string; name: string; role: string };
  scope: string;
  timeframe: string;
}

export const caseStudies: CaseStudy[] = [
  {
    id: 'northwind-patch',
    customerId: 'northwind',
    industry: 'Banking & capital markets',
    title: 'Eleven weeks of quarterly patching, compressed into six days',
    challenge:
      'Northwind ran 18,400 database instances across four regions. Each quarterly cumulative update consumed eleven weeks of elapsed time, most of it spent agreeing sequences that preserved availability-group quorum and negotiating windows with 62 application owners. Two consecutive quarters had finished late, putting the bank outside its own currency policy.',
    approach:
      'Discovery mapped the estate and its dependencies in the first nine days, surfacing 1,340 instances absent from the CMDB. Wave plans were generated from the dependency graph rather than negotiated, with quorum constraints encoded as policy. Health gates between waves decided whether execution continued, and failures re-queued into a trailing wave automatically.',
    results: [
      { value: '6 days', label: 'Quarterly cycle, from 11 weeks' },
      { value: '0 min', label: 'Unplanned downtime across three cycles' },
      { value: '834 hrs', label: 'Engineer hours returned per quarter' },
      { value: '1,340', label: 'Previously undocumented instances found' },
    ],
    quote: {
      text: 'The difference was not speed of execution — it was that nobody had to negotiate a sequence any more.',
      name: 'Rebecca Ashford',
      role: 'Director of Database Engineering',
    },
    scope: '18,400 instances · SQL Server, Oracle, PostgreSQL · 4 regions',
    timeframe: 'Deployed Q1 · first automated cycle Q2',
  },
  {
    id: 'meridian-migration',
    customerId: 'meridian',
    industry: 'Healthcare',
    title: 'Sixty-two hospital migrations without a patient-facing outage',
    challenge:
      'Meridian was consolidating 62 hospital data centres into two regional facilities. Clinical systems have no natural maintenance window, and every change required validated change control. The programme was six months behind after the first eight sites, each of which had been run as a bespoke project.',
    approach:
      'The migration factory turned move groups into a repeatable pipeline. Dependency data drove move-group composition; target environments were built from generated Terraform committed to the platform team’s own repository; every cutover was rehearsed against production data with reconciliation and clinical smoke tests before the real window. Rollback was executed in rehearsal, not documented in a plan.',
    results: [
      { value: '0', label: 'Patient-facing outages' },
      { value: '54 sites', label: 'Completed in the following 11 months' },
      { value: '38 min', label: 'Median cutover duration' },
      { value: '100%', label: 'Cutovers with a rehearsed rollback path' },
    ],
    quote: {
      text: 'Being able to rehearse a cutover against production data, then roll it back cleanly, is what let us move sixty-two hospitals without a single patient-facing outage.',
      name: 'Aaron Feldman',
      role: 'Chief Technology Officer',
    },
    scope: '340 clinical applications · 62 sites · GxP change control',
    timeframe: '14-month programme, delivered on the original date',
  },
  {
    id: 'castellan-compliance',
    customerId: 'castellan',
    industry: 'Insurance',
    title: 'Regulatory evidence in an afternoon, not a six-week exercise',
    challenge:
      'Castellan operates in fourteen countries with obligations under Solvency II, DORA and local regimes. Evidence of control over privileged database access was assembled manually each cycle by four teams, took roughly six weeks, and described a state that had already moved on by the time it was submitted.',
    approach:
      'Technical controls were mapped to the relevant regulatory articles and tested continuously across all 9,700 in-scope systems. Failures became governed remediation workflows with named owners and dates rather than spreadsheet rows. Evidence is now generated in the assessors’ own template with per-check timestamps.',
    results: [
      { value: '1 day', label: 'Evidence preparation, from 6 weeks' },
      { value: '99.1%', label: 'Sustained control pass rate' },
      { value: '0', label: 'Auditor follow-up requests on the first submission' },
      { value: '14', label: 'Jurisdictions covered from one control library' },
    ],
    quote: {
      text: 'We exported it in an afternoon, and the auditors accepted it without a follow-up request.',
      name: 'Marta Lindqvist',
      role: 'Head of Technology Risk',
    },
    scope: '9,700 systems · 14 countries · Solvency II, DORA',
    timeframe: 'First full evidence cycle in month four',
  },
];

/* ==================================================================== BLOG */

export interface Article {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  author: string;
  role: string;
  date: string;
  readingTime: string;
  featured?: boolean;
}

export const articles: Article[] = [
  {
    slug: 'blast-radius-is-the-only-metric',
    title: 'Blast radius is the only change metric that matters',
    excerpt:
      'Change failure rate tells you how often you were wrong. Blast radius tells you how much it cost when you were. Only one of them is something you can decide in advance.',
    category: 'Engineering',
    author: 'Priya Venkataraman',
    role: 'Principal Engineer, Workflow',
    date: '2026-07-28',
    readingTime: '9 min',
    featured: true,
  },
  {
    slug: 'why-cmdbs-drift',
    title: 'Why every CMDB drifts, and what to do instead',
    excerpt:
      'A configuration database records intent. Production records outcome. The gap is not a data-quality problem to be solved — it is a signal to be measured continuously.',
    category: 'Operations',
    author: 'Tom Beckett',
    role: 'Field CTO',
    date: '2026-07-14',
    readingTime: '11 min',
  },
  {
    slug: 'runbooks-that-write-themselves',
    title: 'Runbooks that write themselves still need a reviewer',
    excerpt:
      'Generated procedures are only as safe as the review step that follows them. What we learned putting a human gate in front of every AI-authored runbook.',
    category: 'AI',
    author: 'Sofia Marchetti',
    role: 'Head of Applied AI',
    date: '2026-06-30',
    readingTime: '8 min',
  },
  {
    slug: 'quorum-aware-patching',
    title: 'Quorum-aware patching for availability groups',
    excerpt:
      'A technical walk-through of how wave planning derives sequencing constraints from replication topology, and why naive parallelism loses quorum at scale.',
    category: 'Engineering',
    author: 'Daniel Osei',
    role: 'Staff Engineer, Database Automation',
    date: '2026-06-17',
    readingTime: '14 min',
  },
  {
    slug: 'dora-without-a-programme',
    title: 'Meeting DORA obligations without a two-year programme',
    excerpt:
      'Most of what the regulation asks for is evidence you already generate. The problem is that it lives in six systems and nobody can assemble it on demand.',
    category: 'Compliance',
    author: 'Marta Lindqvist',
    role: 'Guest contributor',
    date: '2026-06-03',
    readingTime: '10 min',
  },
  {
    slug: 'cost-of-an-unattended-restart',
    title: 'The real cost of an unattended restart at 2am',
    excerpt:
      'We modelled the fully-loaded cost of out-of-hours remediation across 40 enterprise estates. The engineer hours are not the expensive part.',
    category: 'Operations',
    author: 'Tom Beckett',
    role: 'Field CTO',
    date: '2026-05-21',
    readingTime: '7 min',
  },
];

/* =============================================================== RESOURCES */

export interface Resource {
  title: string;
  kind: 'Technical brief' | 'Whitepaper' | 'Webinar' | 'Report' | 'Guide' | 'Template';
  description: string;
  href: string;
  meta: string;
}

export const resources: Resource[] = [
  {
    title: 'The autonomous operations reference architecture',
    kind: 'Technical brief',
    description:
      'How a 40,000-node estate runs governed change with a nine-person platform team. Deployment topology, policy model and the failure modes we designed around.',
    href: '/resources',
    meta: '38 pages · updated July 2026',
  },
  {
    title: 'Quantifying the cost of manual infrastructure operations',
    kind: 'Report',
    description:
      'Effort and cost baselines drawn from 40 enterprise estates, broken down by platform, region and change class, with the methodology included.',
    href: '/resources',
    meta: '24 pages · 40 estates surveyed',
  },
  {
    title: 'Mapping DORA technical requirements to infrastructure controls',
    kind: 'Whitepaper',
    description:
      'Article-by-article mapping from the regulation to testable technical controls, with evidence templates for each.',
    href: '/resources',
    meta: '31 pages · reviewed by external counsel',
  },
  {
    title: 'Designing a policy model for unattended remediation',
    kind: 'Guide',
    description:
      'How to decide which failure modes may be resolved without a human, and how to bound them so the decision stays defensible.',
    href: '/resources',
    meta: '18 pages · with worked examples',
  },
  {
    title: 'Patch orchestration at availability-group scale',
    kind: 'Webinar',
    description:
      'A live walkthrough with Northwind Financial’s database engineering team on compressing a quarterly cycle from eleven weeks to six days.',
    href: '/company/events',
    meta: '52 minutes · on demand',
  },
  {
    title: 'Proof of concept scoping template',
    kind: 'Template',
    description:
      'The scoping document we use to define a two-week proof of concept, including the measurement plan that determines whether it succeeded.',
    href: '/contact-sales',
    meta: 'Editable · no registration',
  },
];
