import type { Metadata, Viewport } from 'next';
import localFont from 'next/font/local';
import './globals.css';
import { site } from '@/content/site.config';
import { organizationSchema, websiteSchema, softwareApplicationSchema } from '@/lib/seo';

/**
 * Root layout.
 *
 * Fonts are self-hosted variable files rather than fetched from a third party:
 * one request per family, no render-blocking DNS to a font CDN, and no
 * third-party request for a visitor's browser to make on a page that talks
 * about data residency.
 */

const sans = localFont({
  src: [
    { path: '../../public/fonts/InterVariable.woff2', weight: '100 900', style: 'normal' },
    { path: '../../public/fonts/InterVariable-Italic.woff2', weight: '100 900', style: 'italic' },
  ],
  variable: '--font-inter',
  display: 'swap',
  preload: true,
});

const mono = localFont({
  src: [{ path: '../../public/fonts/JetBrainsMonoVariable.woff2', weight: '100 800', style: 'normal' }],
  variable: '--font-jetbrains',
  display: 'swap',
  preload: true,
});

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: `${site.name} — ${site.tagline} for Modern Enterprises`,
    template: `%s | ${site.name}`,
  },
  description: site.description,
  applicationName: site.name,
  generator: `${site.name} Web Platform`,
  authors: [{ name: site.legalName, url: site.url }],
  creator: site.legalName,
  publisher: site.legalName,
  formatDetection: { telephone: false },
  manifest: '/site.webmanifest',
  icons: {
    icon: [{ url: '/brand/favicon.svg', type: 'image/svg+xml' }],
    apple: [{ url: '/brand/apple-touch-icon.png', sizes: '180x180' }],
  },
  alternates: { canonical: '/' },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
      'max-snippet': -1,
      'max-video-preview': -1,
    },
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  colorScheme: 'dark light',
  themeColor: [
    { media: '(prefers-color-scheme: dark)', color: '#06080c' },
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
  ],
};

/**
 * Applies the stored theme before first paint. Inlined deliberately: any
 * deferred alternative produces a visible flash of the wrong palette, which is
 * far more jarring than a 300-byte blocking script.
 */
const THEME_BOOTSTRAP = `
(function () {
  var d = document.documentElement;
  d.classList.remove('no-js');
  try {
    var stored = localStorage.getItem('aetherion-theme');
    d.setAttribute('data-theme', stored || (window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'));
  } catch (e) {
    d.setAttribute('data-theme', 'dark');
  }
})();
`.trim();

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      data-theme="dark"
      className={`no-js ${sans.variable} ${mono.variable}`}
      suppressHydrationWarning
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: THEME_BOOTSTRAP }} />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify([
              organizationSchema(),
              websiteSchema(),
              softwareApplicationSchema(),
            ]),
          }}
        />
      </head>
      <body>
        <a className="skip-link" href="#main">
          Skip to main content
        </a>
        {children}
      </body>
    </html>
  );
}
