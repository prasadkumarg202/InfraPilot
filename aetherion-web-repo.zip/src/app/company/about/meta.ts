import type { PageMeta } from '@/lib/seo';

export const meta: PageMeta = {
  title: 'About Aetherion',
  description:
    'Why Aetherion exists: enterprise estates outgrew the operating models built to run them, and the gap is not something more headcount closes.',
  path: '/company/about',
  breadcrumbs: [
    { name: 'Company', href: '/company' },
    { name: 'About', href: '/company/about' },
  ],
};
